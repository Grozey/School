﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Graf
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void klikBtn(object sender, int value1, int value2, EventArgs e)
        {
            folder.SelectedPath = label1.Text;
            if (folder.ShowDialog() == DialogResult.OK)
            {
                label1.Text = folder.SelectedPath;
            }
        }
    }
    private static void DrawPieChart(Graphics gr, Rectangle rect, Brush[] brushes, Pen[] pens, float[] values)
    {
        float total = values.Sum();
        float start_angle = 0;
        for (int i = 0; i < values.Length; i++)
        {
            float sweep_angle = values[i] * 360f / total;
            gr.FillPie(brushes[i % brushes.Length],
                rect, start_angle, sweep_angle);
            gr.DrawPie(pens[i % pens.Length],
                rect, start_angle, sweep_angle);
            start_angle += sweep_angle;
        }
    }
    private Brush[] SliceBrushes =
{
    Brushes.Red,
    Brushes.LightGreen,
    Brushes.Blue,
    Brushes.LightBlue,
    Brushes.Green,
    Brushes.Lime,
    Brushes.Orange,
    Brushes.Fuchsia,
    Brushes.Yellow,
    Brushes.Cyan,
};

    // Pens used to outline pie slices.
    private Pen[] SlicePens = { Pens.Black };

    // The data values to chart.
    private float[] Values = new float[10];

    // Make some random data.
    private void Form1_Load(object sender, EventArgs e)
    {
        Random rand = new Random();
        for (int i = 0; i < Values.Length; i++)
        {
            Values[i] = rand.Next(10, 40);
        }
    }
}
