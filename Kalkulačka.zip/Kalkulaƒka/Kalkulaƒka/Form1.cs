﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalkulačka
{
    public partial class Form1 : Form
    {
        double FirstNumber;
        string Operation;
        double SecondNumber;
        double Result;
        string control1;
        string control2;
        public Form1()
        {
            InitializeComponent();
        }

        private void n1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "1";
            }
            else
            {
                textBox1.Text = textBox1.Text + "1";
            }
        }
        private void n2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "2";
            }
            else
            {
                textBox1.Text = textBox1.Text + "2";
            }
        }
        private void n3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "3";
            }
            else
            {
                textBox1.Text = textBox1.Text + "3";
            }
        }
        private void n4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "4";
            }
            else
            {
                textBox1.Text = textBox1.Text + "4";
            }
        }
        private void n5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "5";
            }
            else
            {
                textBox1.Text = textBox1.Text + "5";
            }
        }
        private void n6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "6";
            }
            else
            {
                textBox1.Text = textBox1.Text + "6";
            }
        }
        private void n7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "7";
            }
            else
            {
                textBox1.Text = textBox1.Text + "7";
            }
        }
        private void n8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "8";
            }
            else
            {
                textBox1.Text = textBox1.Text + "8";
            }
        }
        private void n9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "9";
            }
            else
            {
                textBox1.Text = textBox1.Text + "9";
            }
        }
        private void null_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                textBox1.Text = "0";
            }
            else
            {
                textBox1.Text = textBox1.Text + "0";
            }
        }
        private void plus_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "+";
            Operation = "+";
            control1 = textBox1.Text;
        }
        private void min_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "-";
            Operation = "-";

        }
        private void krat_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "*";
            Operation = "*";
        }
        private void deleni_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "/";
            Operation = "/";
        }
        private void maz_Click(object sender, EventArgs e)
        {
        
        }
        private void mazall_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";
        }
        private void carka_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text + ".";
        }
        private void nadve_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "^2";
        }
        private void nan_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "^";
        }
        private void odm_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "√";
        }
        private void odmn_Click(object sender, EventArgs e)
        {
            FirstNumber = Convert.ToDouble(textBox1.Text);
            textBox1.Text = textBox1.Text + "n√";
        }
        private void time(object sender, EventArgs e)
        {           
            control2 = textBox1.Text;
            if (control1 != control2)
            {
                SecondNumber = Convert.ToDouble(textBox1.Text);
                if (Convert.ToString(SecondNumber) == control1)
                {
                    textBox2.Text = Convert.ToString(FirstNumber);
                }
                else
                {
                    if (Operation == "+")
                    {
                        Result = Convert.ToDouble(textBox1.Text);
                        textBox2.Text = Convert.ToString(Result);
                    }
                    else if (Operation == "-")
                    {
                        Result = (FirstNumber - SecondNumber);
                        textBox2.Text = Convert.ToString(Result);
                    }
                    else if (Operation == "*")
                    {
                        SecondNumber = Convert.ToDouble(textBox1.Text);
                        Result = (FirstNumber * SecondNumber);
                        textBox2.Text = Convert.ToString(Result);
                    }
                    else if (Operation == "/")
                    {
                        if (SecondNumber == 0)
                        {
                            textBox2.Text = "Error";
                        }
                        else
                        {
                            SecondNumber = Convert.ToDouble(textBox1.Text);
                            Result = (FirstNumber / SecondNumber);
                            textBox2.Text = Convert.ToString(Result);
                        }
                    }
                    else
                    {

                        textBox2.Text = textBox1.Text;
                    }
                }
            }
            else
            {

                textBox2.Text = Convert.ToString(FirstNumber);
            }
        }
        private void rovnase_Click(object sender, EventArgs e)
        {
            textBox1.Text = Convert.ToString(Result);
        }
    }
}
