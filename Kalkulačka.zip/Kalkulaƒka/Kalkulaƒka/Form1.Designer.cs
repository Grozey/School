﻿namespace Kalkulačka
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.minus = new System.Windows.Forms.Button();
            this.nul = new System.Windows.Forms.Button();
            this.carka = new System.Windows.Forms.Button();
            this.rovnase = new System.Windows.Forms.Button();
            this.n1 = new System.Windows.Forms.Button();
            this.n2 = new System.Windows.Forms.Button();
            this.n3 = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.n4 = new System.Windows.Forms.Button();
            this.n5 = new System.Windows.Forms.Button();
            this.n6 = new System.Windows.Forms.Button();
            this.min = new System.Windows.Forms.Button();
            this.n7 = new System.Windows.Forms.Button();
            this.n8 = new System.Windows.Forms.Button();
            this.n9 = new System.Windows.Forms.Button();
            this.krat = new System.Windows.Forms.Button();
            this.nadve = new System.Windows.Forms.Button();
            this.nan = new System.Windows.Forms.Button();
            this.maz = new System.Windows.Forms.Button();
            this.deleni = new System.Windows.Forms.Button();
            this.odm = new System.Windows.Forms.Button();
            this.odmn = new System.Windows.Forms.Button();
            this.mazall = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.sin = new System.Windows.Forms.Button();
            this.cos = new System.Windows.Forms.Button();
            this.tg = new System.Windows.Forms.Button();
            this.cotg = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox1.Location = new System.Drawing.Point(12, 21);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(378, 81);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // minus
            // 
            this.minus.Location = new System.Drawing.Point(12, 486);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(90, 50);
            this.minus.TabIndex = 1;
            this.minus.Text = "(-)";
            this.minus.UseVisualStyleBackColor = true;
            // 
            // nul
            // 
            this.nul.Location = new System.Drawing.Point(108, 486);
            this.nul.Name = "nul";
            this.nul.Size = new System.Drawing.Size(90, 50);
            this.nul.TabIndex = 2;
            this.nul.Text = "0";
            this.nul.UseVisualStyleBackColor = true;
            this.nul.Click += new System.EventHandler(this.null_Click);
            // 
            // carka
            // 
            this.carka.Location = new System.Drawing.Point(204, 486);
            this.carka.Name = "carka";
            this.carka.Size = new System.Drawing.Size(90, 50);
            this.carka.TabIndex = 3;
            this.carka.Text = ",";
            this.carka.UseVisualStyleBackColor = true;
            this.carka.Click += new System.EventHandler(this.carka_Click);
            // 
            // rovnase
            // 
            this.rovnase.Location = new System.Drawing.Point(300, 430);
            this.rovnase.Name = "rovnase";
            this.rovnase.Size = new System.Drawing.Size(90, 50);
            this.rovnase.TabIndex = 4;
            this.rovnase.Text = "=";
            this.rovnase.UseVisualStyleBackColor = true;
            this.rovnase.Click += new System.EventHandler(this.rovnase_Click);
            // 
            // n1
            // 
            this.n1.Location = new System.Drawing.Point(12, 430);
            this.n1.Name = "n1";
            this.n1.Size = new System.Drawing.Size(90, 50);
            this.n1.TabIndex = 5;
            this.n1.Text = "1";
            this.n1.UseVisualStyleBackColor = true;
            this.n1.Click += new System.EventHandler(this.n1_Click);
            // 
            // n2
            // 
            this.n2.Location = new System.Drawing.Point(108, 430);
            this.n2.Name = "n2";
            this.n2.Size = new System.Drawing.Size(90, 50);
            this.n2.TabIndex = 6;
            this.n2.Text = "2";
            this.n2.UseVisualStyleBackColor = true;
            this.n2.Click += new System.EventHandler(this.n2_Click);
            // 
            // n3
            // 
            this.n3.Location = new System.Drawing.Point(204, 430);
            this.n3.Name = "n3";
            this.n3.Size = new System.Drawing.Size(90, 50);
            this.n3.TabIndex = 7;
            this.n3.Text = "3";
            this.n3.UseVisualStyleBackColor = true;
            this.n3.Click += new System.EventHandler(this.n3_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(300, 374);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(90, 50);
            this.plus.TabIndex = 8;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // n4
            // 
            this.n4.Location = new System.Drawing.Point(12, 374);
            this.n4.Name = "n4";
            this.n4.Size = new System.Drawing.Size(90, 50);
            this.n4.TabIndex = 9;
            this.n4.Text = "4";
            this.n4.UseVisualStyleBackColor = true;
            this.n4.Click += new System.EventHandler(this.n4_Click);
            // 
            // n5
            // 
            this.n5.Location = new System.Drawing.Point(108, 374);
            this.n5.Name = "n5";
            this.n5.Size = new System.Drawing.Size(90, 50);
            this.n5.TabIndex = 10;
            this.n5.Text = "5";
            this.n5.UseVisualStyleBackColor = true;
            this.n5.Click += new System.EventHandler(this.n5_Click);
            // 
            // n6
            // 
            this.n6.Location = new System.Drawing.Point(204, 374);
            this.n6.Name = "n6";
            this.n6.Size = new System.Drawing.Size(90, 50);
            this.n6.TabIndex = 11;
            this.n6.Text = "6";
            this.n6.UseVisualStyleBackColor = true;
            this.n6.Click += new System.EventHandler(this.n6_Click);
            // 
            // min
            // 
            this.min.Location = new System.Drawing.Point(300, 318);
            this.min.Name = "min";
            this.min.Size = new System.Drawing.Size(90, 50);
            this.min.TabIndex = 12;
            this.min.Text = "-";
            this.min.UseVisualStyleBackColor = true;
            this.min.Click += new System.EventHandler(this.min_Click);
            // 
            // n7
            // 
            this.n7.Location = new System.Drawing.Point(12, 319);
            this.n7.Name = "n7";
            this.n7.Size = new System.Drawing.Size(90, 50);
            this.n7.TabIndex = 13;
            this.n7.Text = "7";
            this.n7.UseVisualStyleBackColor = true;
            this.n7.Click += new System.EventHandler(this.n7_Click);
            // 
            // n8
            // 
            this.n8.Location = new System.Drawing.Point(108, 318);
            this.n8.Name = "n8";
            this.n8.Size = new System.Drawing.Size(90, 50);
            this.n8.TabIndex = 14;
            this.n8.Text = "8";
            this.n8.UseVisualStyleBackColor = true;
            this.n8.Click += new System.EventHandler(this.n8_Click);
            // 
            // n9
            // 
            this.n9.Location = new System.Drawing.Point(204, 319);
            this.n9.Name = "n9";
            this.n9.Size = new System.Drawing.Size(90, 50);
            this.n9.TabIndex = 15;
            this.n9.Text = "9";
            this.n9.UseVisualStyleBackColor = true;
            this.n9.Click += new System.EventHandler(this.n9_Click);
            // 
            // krat
            // 
            this.krat.Location = new System.Drawing.Point(300, 263);
            this.krat.Name = "krat";
            this.krat.Size = new System.Drawing.Size(90, 50);
            this.krat.TabIndex = 16;
            this.krat.Text = "x";
            this.krat.UseVisualStyleBackColor = true;
            this.krat.Click += new System.EventHandler(this.krat_Click);
            // 
            // nadve
            // 
            this.nadve.Location = new System.Drawing.Point(12, 262);
            this.nadve.Name = "nadve";
            this.nadve.Size = new System.Drawing.Size(90, 50);
            this.nadve.TabIndex = 17;
            this.nadve.Text = "a^2";
            this.nadve.UseVisualStyleBackColor = true;
            this.nadve.Click += new System.EventHandler(this.nadve_Click);
            // 
            // nan
            // 
            this.nan.Location = new System.Drawing.Point(108, 262);
            this.nan.Name = "nan";
            this.nan.Size = new System.Drawing.Size(90, 50);
            this.nan.TabIndex = 18;
            this.nan.Text = "a^n";
            this.nan.UseVisualStyleBackColor = true;
            this.nan.Click += new System.EventHandler(this.nan_Click);
            // 
            // maz
            // 
            this.maz.Location = new System.Drawing.Point(204, 262);
            this.maz.Name = "maz";
            this.maz.Size = new System.Drawing.Size(90, 50);
            this.maz.TabIndex = 19;
            this.maz.Text = "C";
            this.maz.UseVisualStyleBackColor = true;
            this.maz.Click += new System.EventHandler(this.maz_Click);
            // 
            // deleni
            // 
            this.deleni.Location = new System.Drawing.Point(300, 207);
            this.deleni.Name = "deleni";
            this.deleni.Size = new System.Drawing.Size(90, 50);
            this.deleni.TabIndex = 20;
            this.deleni.Text = "÷";
            this.deleni.UseVisualStyleBackColor = true;
            this.deleni.Click += new System.EventHandler(this.deleni_Click);
            // 
            // odm
            // 
            this.odm.Location = new System.Drawing.Point(12, 207);
            this.odm.Name = "odm";
            this.odm.Size = new System.Drawing.Size(90, 50);
            this.odm.TabIndex = 17;
            this.odm.Text = "√x";
            this.odm.UseVisualStyleBackColor = true;
            this.odm.Click += new System.EventHandler(this.odm_Click);
            // 
            // odmn
            // 
            this.odmn.Location = new System.Drawing.Point(108, 206);
            this.odmn.Name = "odmn";
            this.odmn.Size = new System.Drawing.Size(90, 50);
            this.odmn.TabIndex = 18;
            this.odmn.Text = "n√x";
            this.odmn.UseVisualStyleBackColor = true;
            this.odmn.Click += new System.EventHandler(this.odmn_Click);
            // 
            // mazall
            // 
            this.mazall.Location = new System.Drawing.Point(204, 206);
            this.mazall.Name = "mazall";
            this.mazall.Size = new System.Drawing.Size(90, 50);
            this.mazall.TabIndex = 19;
            this.mazall.Text = "CE";
            this.mazall.UseVisualStyleBackColor = true;
            this.mazall.Click += new System.EventHandler(this.mazall_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.time);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.White;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.textBox2.Location = new System.Drawing.Point(12, 99);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(378, 39);
            this.textBox2.TabIndex = 21;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // sin
            // 
            this.sin.Location = new System.Drawing.Point(12, 151);
            this.sin.Name = "sin";
            this.sin.Size = new System.Drawing.Size(90, 50);
            this.sin.TabIndex = 22;
            this.sin.Text = "sin(x)";
            this.sin.UseVisualStyleBackColor = true;
            // 
            // cos
            // 
            this.cos.Location = new System.Drawing.Point(108, 151);
            this.cos.Name = "cos";
            this.cos.Size = new System.Drawing.Size(90, 50);
            this.cos.TabIndex = 23;
            this.cos.Text = "cos(x)";
            this.cos.UseVisualStyleBackColor = true;
            // 
            // tg
            // 
            this.tg.Location = new System.Drawing.Point(204, 151);
            this.tg.Name = "tg";
            this.tg.Size = new System.Drawing.Size(90, 50);
            this.tg.TabIndex = 24;
            this.tg.Text = "tg(x)";
            this.tg.UseVisualStyleBackColor = true;
            // 
            // cotg
            // 
            this.cotg.Location = new System.Drawing.Point(300, 151);
            this.cotg.Name = "cotg";
            this.cotg.Size = new System.Drawing.Size(90, 50);
            this.cotg.TabIndex = 25;
            this.cotg.Text = "cotg(x)";
            this.cotg.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 548);
            this.Controls.Add(this.cotg);
            this.Controls.Add(this.tg);
            this.Controls.Add(this.cos);
            this.Controls.Add(this.sin);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.deleni);
            this.Controls.Add(this.maz);
            this.Controls.Add(this.mazall);
            this.Controls.Add(this.odmn);
            this.Controls.Add(this.nan);
            this.Controls.Add(this.odm);
            this.Controls.Add(this.nadve);
            this.Controls.Add(this.krat);
            this.Controls.Add(this.n9);
            this.Controls.Add(this.n8);
            this.Controls.Add(this.n7);
            this.Controls.Add(this.min);
            this.Controls.Add(this.n6);
            this.Controls.Add(this.n5);
            this.Controls.Add(this.n4);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.n3);
            this.Controls.Add(this.n2);
            this.Controls.Add(this.n1);
            this.Controls.Add(this.rovnase);
            this.Controls.Add(this.carka);
            this.Controls.Add(this.nul);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Kalkulačka";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button nul;
        private System.Windows.Forms.Button carka;
        private System.Windows.Forms.Button rovnase;
        private System.Windows.Forms.Button n1;
        private System.Windows.Forms.Button n2;
        private System.Windows.Forms.Button n3;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button n4;
        private System.Windows.Forms.Button n5;
        private System.Windows.Forms.Button n6;
        private System.Windows.Forms.Button min;
        private System.Windows.Forms.Button n7;
        private System.Windows.Forms.Button n8;
        private System.Windows.Forms.Button n9;
        private System.Windows.Forms.Button krat;
        private System.Windows.Forms.Button nadve;
        private System.Windows.Forms.Button nan;
        private System.Windows.Forms.Button maz;
        private System.Windows.Forms.Button deleni;
        private System.Windows.Forms.Button odm;
        private System.Windows.Forms.Button odmn;
        private System.Windows.Forms.Button mazall;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button sin;
        private System.Windows.Forms.Button cos;
        private System.Windows.Forms.Button tg;
        private System.Windows.Forms.Button cotg;
    }
}

