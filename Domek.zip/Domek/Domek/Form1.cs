﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Threading;

namespace Domek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void PB_resize(object sender, EventArgs e)
        {
            pictureBox1.Invalidate();
        }

        private void PB_paint(object sender, PaintEventArgs e)
        {
            Render(e.Graphics);
        }
        private void Render(Graphics grp)
        {
            int lw = (pictureBox1.Width / 4);
            int mw = 2 * (pictureBox1.Width / 4);
            int rw = 3 * (pictureBox1.Width / 4);
            int th = (pictureBox1.Height / 4);
            int mh = 2 * (pictureBox1.Height / 4);
            int bh = 3 * (pictureBox1.Height / 4);
            grp.SmoothingMode = SmoothingMode.AntiAlias;
            grp.DrawLine(Pens.Black, rw, bh, lw, bh);
            grp.DrawLine(Pens.Black, lw, bh, lw, mh);
            grp.DrawLine(Pens.Black, lw, mh, rw, mh);
            grp.DrawLine(Pens.Black, rw, mh, mw, th);
            grp.DrawLine(Pens.Black, mw, th, lw, mh);
            grp.DrawLine(Pens.Black, lw, mh, rw, bh);
            grp.DrawLine(Pens.Black, rw, bh, rw, mh);
            grp.DrawLine(Pens.Black, rw, mh, lw, bh);
        }
    }
}
